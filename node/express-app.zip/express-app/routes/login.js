const sql = require("../sql/sqlConfig");
const tokenObj = require('../util/jwt.js');
const express = require('express');
const crypto = require("crypto");

let router = express.Router();

router.post('/', function (req, res, next) {
    let is_admin = req.body.is_admin;
    let username = req.body.username;
    let password = req.body.password;
    let md5 = crypto.createHash("md5");
    let newPas = md5.update(password).digest("hex");
    let option = "select * from user where is_admin='"+is_admin+"' and email='"+username+"' and password='"+newPas+"'";
    sql.query(option, function (err, rows) {
        if (err) {
            return res.send({errCode:-9999,message:'查询失败:'+err})
        } else {
            if(rows.length==0){
                return res.send({errCode:9,message:'用户名或者密码错误'});
            }
            let userInfo = {
                id:rows[0].id,
                email:rows[0].email
            };
            let result = {
                id:rows[0].id,
                email:rows[0].email,
                join_date: rows[0].join_date,
                level_id: rows[0].level_id
            };
            let myToken = new tokenObj();
            let tokenv = myToken.createToken(userInfo, 60 * 20);//20分钟
            res.send({errCode:0,message:'登陆成功',result:{token:tokenv,userInfo:result}});
        }
    })
});
module.exports = router;


